package com.foodstore.dao;

import com.foodstore.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final class UserMapper implements RowMapper<User> {
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User user = new User();
            user.setId(rs.getLong("id"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            return user;
        }
    }
	
    public User createUser(final User user) {
        final String sql =;

        GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
                PreparedStatement psst = connection.prepareStatement(sql, new String[]{"id"});
                psst.setString(1, user.getUsername());
                psst.setString(2, user.getPassword());
                return psst;
            }
        }, keyHolder);

        user.setId(keyHolder.getKey().longValue());
        return user;
    }

    public User updateUser(User user) {
        String sql = ;
        jdbcTemplate.update(sql, user.getUsername(), user.getPassword(), user.getId());
        return user;
    }

    public void deleteUser(String username) {
        String sql =;
        jdbcTemplate.update(sql, username);
    }


    private boolean exists(Long userId, Long roleId) {
        String sql = ;
        return jdbcTemplate.queryForObject(sql, Integer.class, userId, roleId) != 0;
    }

    public User findOne(Long userId) {
        String sql = ;
        List<User> userList = jdbcTemplate.query(sql, new UserMapper(), userId);
        if(userList.size() == 0) {
            return null;
        }
        return userList.get(0);
    }

    public User findByUsername(String username) {
        String sql = ;
        List<User> userList = jdbcTemplate.query(sql, new UserMapper(), username);
        if(userList.size() == 0) {
            return null;
        }
        return userList.get(0);
    }

    
}
